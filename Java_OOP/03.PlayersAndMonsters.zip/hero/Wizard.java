package hero;

public class Wizard extends Hero {
    public Wizard(String username, int level) {
        super(username, level);
    }
}
