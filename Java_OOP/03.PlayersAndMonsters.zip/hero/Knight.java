package hero;

public class Knight extends Hero{
    public Knight(String username, int leve) {
        super(username, leve);
    }
}
