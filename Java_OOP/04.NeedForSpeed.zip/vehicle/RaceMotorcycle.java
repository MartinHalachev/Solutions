package vehicle;

public class RaceMotorcycle extends Motorcycle {
    final static double DEFAULT_FUEL_CONSUMPTION = 8.00;

    public RaceMotorcycle(int fuel, int horsePower) {
        super(fuel, horsePower);
        this.setFuelConsumption(DEFAULT_FUEL_CONSUMPTION);
    }
}
