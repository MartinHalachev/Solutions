package vehicle;

public class Car extends Vehicle{
    final static double DEFAULT_FUEL_CONSUMPTION = 3.00;

    public Car(int fuel, int horsePower) {
        super(fuel, horsePower);
        this.setFuelConsumption(DEFAULT_FUEL_CONSUMPTION);
    }
}
