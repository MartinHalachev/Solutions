package vehicle;

public class Motorcycle extends Vehicle {

    public Motorcycle(int fuel, int horsePower) {
        super(fuel, horsePower);
    }

}
