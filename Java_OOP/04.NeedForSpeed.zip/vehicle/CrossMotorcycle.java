package vehicle;

public class CrossMotorcycle extends Motorcycle{

    public CrossMotorcycle(int fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
