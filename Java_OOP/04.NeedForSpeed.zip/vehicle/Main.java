package vehicle;

public class Main {
    public static void main(String[] args) {
        RaceMotorcycle car = new RaceMotorcycle(10,10);
        Car car1 = new SportCar(10,10);

    }
}
