package vehicle;

public class FamilyCar extends Car{
    public FamilyCar(int fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
